<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="row">
  <div class="col-md-1">
  </div>
  <div class="col-md-10">
    <?php if(\Session::has('success')): ?>
                <div class="alert alert-success my-alert" >
                    <hr>    
                    <ul>
                        <li><?php echo \Session::get('success'); ?></li>
                    </ul>
                </div>
            <?php endif; ?>
            <script>
                document.querySelector('.my-alert').style.display = 'block';
            setTimeout(function() {
              document.querySelector('.my-alert').style.display = 'none';
            }, 4000);
                </script>
    <span>All articles made by users</span>
    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card-body well ">
      <div class="d-flex justify-content-center">
      <span><strong><a href='/admin/profile/<?php echo e($note->user_id); ?>'><?php echo e($note->author); ?></a></strong> ::</span>
      
      <span class="success"><?php echo e($note->title); ?></span>
      <hr>
    <a class="btn btn-primary btn-sm" href="/article/review/<?php echo e($note->id); ?>" title="Approve">Approve</a>
 
  <br>
      <hr>
    </div>
    <div class="form-panel"> <?php echo html_entity_decode($note->word); ?>

<hr>
    </div>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <div class="col-md-1">
  </div>
</div>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arnoldn/projects/pefa_njiru/resources/views/admin/approveArticle.blade.php ENDPATH**/ ?>