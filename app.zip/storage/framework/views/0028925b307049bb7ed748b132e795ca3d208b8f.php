<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Pefa Church</title>
	<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/pefa_custom.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('css/lib/font-awesome/css/font-awesome.css')); ?>">
	<style>
		.section-header .section-title {
  font-size: 32px;
  color: #111;
  text-transform: uppercase;
  text-align: center;
  font-weight: 700;
  margin-bottom: 5px;
}

.section-header .section-description {
  text-align: center;
  padding-bottom: 40px;
  color: #999;
}
		#team {
		  background: #fff;
		  padding: 80px 0 60px 0;
		}

		#team .member {
		  text-align: center;
		  margin-bottom: 20px;
		}

		#team .member .pic {
		  margin-bottom: 15px;
		  overflow: hidden;
		  height: 260px;
		}

		#team .member .pic img {
		  max-width: 100%;
		}

		#team .member h4 {
		  font-weight: 700;
		  margin-bottom: 2px;
		  font-size: 18px;
		}

		#team .member span {
		  font-style: italic;
		  display: block;
		  font-size: 13px;
		}

		#team .member .social {
		  margin-top: 15px;
		}

		#team .member .social a {
		  color: #b3b3b3;
		}

		#team .member .social a:hover {
		  color: #2dc997;
		}

		#team .member .social i {
		  font-size: 18px;
		  margin: 0 2px;
		}

	</style>
	
</head>
<body>
	<header id="header" class="bg-info">
		<div class="row">			
			<div class="col">
				<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
				  <div class="container">
				    <a class="navbar-brand" href="#">
				          PEFA CHURCH NJIRU
				        </a>
				    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
				          <span class="navbar-toggler-icon"></span>
				        </button>
				    <div class="collapse navbar-collapse" id="navbarResponsive">
				      <ul class="navbar-nav ml-auto">
				        <li class="nav-item active">
				          <a class="nav-link" href="/"><span class="text-primary">Home</span>
				                <span class="sr-only">(current)</span>
				              </a>
				        </li>	
				        <li class="nav-item">
				          <a class="nav-link" href="/a_word"><span class="text-primary">A word</span></a>
				        </li>			        
				        <li class="nav-item">
				          <a class="nav-link" href="/weekly"><span class="text-primary">Weekly</span></a>
				        </li>
				        <li class="nav-item">
				          <a class="nav-link" href="/history"><span class="text-primary">History</span></a>
				        </li>
				        <li class="nav-item">
				          <a class="nav-link" href="/gallery"><span class="text-primary">Gallery</span></a>
				        </li>
				        <li class="nav-item">
				          <a class="nav-link" href="/news"><span class="text-primary">News</span></a>
				        </li>
				        <li class="nav-item">
				          <a class="nav-link" href="/contact_us"><span class="text-primary">Contact</span></a>
				        </li>
				      </ul>
				    </div>
				 
				</nav>
			</div>
		</div>
		
	</header><!-- /header -->

	<section class="wrapper">
		<main>
	
		<hr>
		<?php if(\Session::has('success')): ?>
	    <div class="alert alert-success my-alert" >
	    	<hr>   	
	        <ul>
	            <li><?php echo \Session::get('success'); ?></li>
	        </ul>
	    </div>
	<?php endif; ?>
	<script>
		document.querySelector('.my-alert').style.display = 'block';
	setTimeout(function() {
	  document.querySelector('.my-alert').style.display = 'none';
	}, 4000);
		</script>
		<?php echo $__env->yieldContent('content'); ?>
		</main>		
	</section>

	<footer id="sticky-footer" class="bg-primary text-white-50 footer fixed-bottom">
	    <div class="container text-center">
	    	
	    	
	      <small><strong>Copyright &copy; <span><?php echo e(date('Y')); ?></span> <span><strong>.</strong></span> pefachurch.org</strong></small>
	    	
	    </div>
	  </footer>	
	  
	      <script src="<?php echo e(asset('js/app.js')); ?>"></script>
	      <script src="<?php echo e(asset('css/js/jquery/jquery-2.2.4.min.js')); ?>"></script>
	      </body>
</html><?php /**PATH E:\html\pefa_njiru\resources\views/layouts/app.blade.php ENDPATH**/ ?>