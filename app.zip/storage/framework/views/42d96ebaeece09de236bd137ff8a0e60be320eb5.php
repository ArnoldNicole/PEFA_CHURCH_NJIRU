<?php $__env->startSection('content'); ?>
<?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="row justify-content-center mb-3">
			<div class="col-md-8 ">
				<div class="card">
				<div class="card-header bg-light text-success font-weight-bold"><?php echo e($new->title); ?>

					<a href="/admin/news/edit/<?php echo e($new->id); ?>" class="btn btn-outline-secondary float-right">Edit</a></div>
				<div class="card-body">
					<?php echo html_entity_decode($new->body); ?>

				</div>
				<div class="card-footer bg-light">
					<a href="#" class="float-left btn btn-outline-info mr-4">Add News Icon</a>
					<form action="/admin/news/delete/<?php echo e($new->id); ?>" method="POST">
						<?php echo csrf_field(); ?>
						<?php echo method_field('delete'); ?>
						<button type="button" id="Close<?php echo e($new->id); ?>"  class="btn btn-outline-danger float-rignt" onclick="
						document.getElementById('WarningBox<?php echo e($new->id); ?>').style.display='block';
						document.getElementById('Close<?php echo e($new->id); ?>').style.display='none';
						">Delete</button>
						<div class="row justify-content-center" id="WarningBox<?php echo e($new->id); ?>" style="display:none;">
							<div class="col-md-8">
								<p>Are you sure You Want to delete The Item?</p>
								<button type="submit" class="btn btn-outline-danger mr-3">Delete News Item</button>
								<button type="button" class="btn btn-outline-success" onclick="document.getElementById('WarningBox<?php echo e($new->id); ?>').style.display='none';
								document.getElementById('Close<?php echo e($new->id); ?>').style.display='initial';">Cancel</button>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\html\pefa_njiru\resources\views/admin/mynews.blade.php ENDPATH**/ ?>