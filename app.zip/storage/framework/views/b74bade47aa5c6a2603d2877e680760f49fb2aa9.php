<?php $__env->startSection('content'); ?>
     <div class="mt-5">
       <div class="row justify-content-center mt-4">
        <h1 class="col-md-6 font-weight-bold text-dark outline">Our Weekly Events </h1>
       
       </div>
       <div class="row justify-content-center"> 
       <div class="col-md-10">       
        <?php $__currentLoopData = $weekly; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $week): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="#">
         <div class="card mt-4 border border-info col-lg-6 animated tada card-outline-primary" >
          <div class="card-header bg-white font-weight-bold text-info h5 text-center font-weight-bold animated wobble">
            <?php echo e($week->day); ?>

          </div>
          <div class="card-body">
           <?php echo html_entity_decode($week->event); ?>

          </div>           
         </div>
       </a>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
         </div>             
       </div>

     </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\html\pefa_njiru\resources\views/weekly.blade.php ENDPATH**/ ?>