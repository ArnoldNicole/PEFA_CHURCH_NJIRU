<?php $__env->startSection('content'); ?>
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800"><?php echo e(auth()->user()->name); ?></h1>
          </div>
          <div class="row">
            <div class="col-md-3">
              <i class="fa fa-inbox"></i>
            </div>
            <div class="col-md-8">
              <?php $__currentLoopData = $viewAllMessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <div class="card shadow mb-4">
                              <!-- Card Header - Accordion -->
                              <a href="#collapseCardExample<?php echo e($message->id); ?>" class="d-block card-header py-3" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="collapseCardExample">
                                <h6 class="m-0 font-weight-bold text-primary">From | <?php echo e($message->email); ?><span class="float-right"><?php echo e($message->name); ?></span></h6>
                              </a>
                              <!-- Card Content - Collapse -->
                              <div class="collapse show" id="collapseCardExample<?php echo e($message->id); ?>">
                                <div class="card-body">
                                  <div>
                                    <div class="text-muted">
                                      <?php echo e($message->message); ?>

                                    </div>
                                  <hr>
                                  <button id="reply<?php echo e($message->id); ?>" class="btn btn-success"
                                   onclick="document.getElementById('Form<?php echo e($message->id); ?>').style.display='block';
                                   document.getElementById('cancelBtn<?php echo e($message->id); ?>').style.display='block';
                                  document.getElementById('reply<?php echo e($message->id); ?>').style.display='none'">Reply</button>
                                  <br>
                                  <button id="cancelBtn<?php echo e($message->id); ?>" style="display: none" class="btn btn-danger" onclick="document.getElementById('reply<?php echo e($message->id); ?>').style.display='initial';
                                  document.getElementById('cancelBtn<?php echo e($message->id); ?>').style.display='none';
                                  document.getElementById('Form<?php echo e($message->id); ?>').style.display='none';

                                  ">Cancel</button>
                                  <br>
                                  <hr>
                                  <form action="/admin/SENDrePLY/<?php echo e($message->id); ?>" method="POST" class="form-panel" id="Form<?php echo e($message->id); ?>" style="display: none">
                                    <?php echo csrf_field(); ?>
                                  <div class="input-group">
                                    <label>To</label>
                                    <input type="email" name="email" value="<?php echo e($message->email); ?>" class="form-control">
                                  </div> 
                                  <hr>
                                  <div class="input-group">
                                    <label>Text Reply</label>
                                    <textarea name="reply" rows="3" minlength="10" class="form-control" required></textarea>

                                  </div> 
                                  <button type="submit" class="btn btn-warning">Send Reply</button>
                                  
                                  </form>
                                </div>
                              </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
          </div>


          <!-- Content Row -->

        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arnoldn/projects/pefa_njiru/resources/views/admin/contact.blade.php ENDPATH**/ ?>