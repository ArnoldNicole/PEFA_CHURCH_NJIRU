<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
	<div class="col-md-8">
		<?php if($message = Session::get('success')): ?>
		 <div class="alert alert-dismissible alert-success row justify-content-center">
		   <span class="close" data-dismiss="alert">&times;</span>
		   <?php echo e($message); ?>

		 </div>                    
		 <?php endif; ?>

		 <?php if($message = Session::get('error')): ?>
		 <div class="alert alert-dismissible alert-danger row justify-content-center">
		   <span class="close" data-dismiss="alert">&times;</span>
		   <?php echo e($message); ?>

		 </div>                    
		 <?php endif; ?>
	</div>
</div>
<div class="row justify-content-center mt-4">
	<div class="col-md-8">
		<h4 class="text-center font-weight-bold h4 text-primary">
			PEFACHURCHNJIRU.ORG WEB ADMINS & CONTENT CREATORS
		</h4>
		<?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

		<div class="row justify-content-center border border-info">
			<div class="col-md-8">
				<p class="font-weight-bold text-dark">Registered Email: <span class="text-success"><?php echo e($admin->admin_code); ?></span></p>
				<p class="font-weight-bold text-dark">Status: <span class="text-success"><?php echo e($admin->status); ?></span></p>
				<?php if($admin->status=="used"): ?>
					<p class="font-weight-bold text-dark">Admin Name: <span class="text-success"><?php echo e($admin->user->name); ?></span></p>
					<p class="font-weight-bold text-dark">Active since: <span class="text-success"><?php echo e($admin->user->created_at->diffForHumans()); ?></span></p>					
				<?php endif; ?>
			</div>
			<div class="col-md-4">
				<?php if($admin->status=="used"): ?>
				<img src="/storage/<?php echo e($admin->user->profile->image); ?>" alt="Admin Profile" class="img-fluid w-75 mt-3 rounded-circle img-thumbnail ">
				<?php else: ?>
				<img src="/storage/profiles/default.png" alt="Admin Profile" class="img-fluid w-75 mt-3 rounded-circle img-thumbnail ">
				<?php endif; ?>
			</div>
		</div>			
			<div class="dropdown-divider"></div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
</div>
<div class="row justify-content-center mt-4">
	<div class="col-md-8">
		<?php echo e($admins->links()); ?>

	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\html\pefa_njiru\resources\views/admin/list_all_admins.blade.php ENDPATH**/ ?>