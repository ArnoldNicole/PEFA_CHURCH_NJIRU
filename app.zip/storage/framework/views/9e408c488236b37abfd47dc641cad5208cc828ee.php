<?php $__env->startSection('links'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/news.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid mb-4">
	<!-- >>>>>>>>>>>>>>>>>>>>
	     Main Posts Area
	<<<<<<<<<<<<<<<<<<<<< -->
	<div class="mag-posts-content mt-30 mb-30 p-30 box-shadow">
	    <!-- Trending Now Posts Area -->
	    <div class="trending-now-posts mb-30">
	        <!-- Section Title -->
	        <div class="section-heading">
	            <h5>In The News</h5>
	       
	    </div>

	    <!-- Feature Video Posts Area -->
	    <div class="feature-video-posts mb-30">
	        <!-- Section Title -->       

	        <div class="featured-video-posts">
	            <div class="row">
	                <div class="col-12 col-lg-7">
	                	<?php if($news==""): ?>
								<div class="single-featured-post">	
											<div class="post-content">
											    <div class="post-meta">
											        <p>Nothing to show here</p>
											    </div>
											    <a href="#" class="post-title">No News Found</a>
											    <p>No content found on the news server. If you think this is a problem contact admin <a href="mailto:admin@pefachurchnjiru.org" target="_blank">Here</a></p>
											</div>

										
										<div class="post-thumbnail mb-50" align="center">
											<img src="/storage/oops.gif" class="img-thumbnail w-25 img-fluid text-center"  alt="Error gif">
										</div>
									</div>
								</div>

								<?php else: ?>								
								<div class="single-featured-post">
								    <!-- Thumbnail -->
								    <div class="post-thumbnail mb-50">
								        <img src="/img/news-thumbnail.jpeg" alt="">
								        
								    </div>
								    <!-- Post Contetnt -->
								    <div class="post-content">
								        <div class="post-meta">
								            <a href="#"><?php echo e($news->created_at); ?></a>
								            <a href="#"><?php echo e($news->title); ?></a>
								        </div>
								        <a href="#" class="post-title"><?php echo e($news->user->name); ?>: Writer</a>
								        <article><?php echo html_entity_decode($news->body); ?></article>
								    </div>
								    <!-- Post Share Area -->	                   
								</div>
								
	                	<?php endif; ?>
	                    <!-- Single Featured Post -->
	                    
	                </div>

	           <div class="col-12 col-lg-5">
	                    <!-- Featured Video Posts Slide -->


	    <!-- Most Viewed Videos -->
	    <div class="most-viewed-videos mb-30">
	        <!-- Section Title -->
	        <div class="section-heading">
	            <h5>Also..</h5>
	        </div>
	        <ul class="list-group">
	        <?php $__currentLoopData = $allnews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $also): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	        
	        	<?php if($also->id==$news->id): ?>
	        	<span></span>
	        	<?php else: ?>
	        		<li class="list-group-item">
	        		<a href="/news/<?php echo e($also->id); ?>">
	        			<h5 class="h5 text-info text-capitalize"><?php echo e($also->title); ?></h5>
	        		<p><?php echo html_entity_decode(substr($also->body, 0, 150)); ?>...</p>
	        	</a>
	        	</li>	 
	        	<?php endif; ?>       
	        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	        </ul>




	
</div>  
</div>
</div>
</div>
</div>
</div>
</div>

</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<!-- Popper js -->
<script src="<?php echo e(asset('js/js/bootstrap/popper.min.js')); ?>"></script>
<!-- Bootstrap js -->
<script src="<?php echo e(asset('js/js/bootstrap/bootstrap.min.js')); ?>"></script>
<!-- All Plugins js -->
<script src="<?php echo e(asset('js/js/plugins/plugins.js')); ?>"></script>
<!-- Active js -->
<script src="<?php echo e(asset('js/js/active.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\html\pefa_njiru\resources\views/news.blade.php ENDPATH**/ ?>