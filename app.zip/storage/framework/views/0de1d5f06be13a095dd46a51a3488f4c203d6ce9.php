<?php $__env->startSection('links'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/richtext.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
        <div class="container-fluid">
              <?php if(\Session::has('success')): ?>
              <div class="alert alert-danger my-alert" >
                  <hr>    
                  <ul>
                      <li><?php echo \Session::get('success'); ?></li>
                  </ul>
              </div>
          <?php endif; ?>
          <script>
              document.querySelector('.my-alert').style.display = 'block';
          setTimeout(function() {
            document.querySelector('.my-alert').style.display = 'none';
          }, 4000);
              </script>

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800"><?php echo e(auth()->user()->name); ?> Edit  site Article </h1>
          </div>
      <form role="form-horizontal"  action="/admin/article/update/<?php echo e($aword->id); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('patch'); ?>
                    <div class="form-group row">
                      <label class="col-form-label text-md-right col-md-3">Title</label>
                      <div class="input-group col-md-9">            
                          <input type="text" name="title" 
                          class="form-control <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e($aword->title ??  old('title')); ?>" required>
                      
                      <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
                          <span class="invalid-feedback" role="alert">
                              <strong><?php echo e($message); ?></strong>
                          </span>
                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>   
                      </div>      
                    </div> 

                    <div class="form-group row mb-4">
                      <label for="" class="col-md-3 col-form-label text-md-right <?php if ($errors->has('word')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('word'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">Article Errors</label>
                      <div class="col-md-9 input-group">
                        <?php if ($errors->has('word')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('word'); ?>
                            <span class="alert alert-danger">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                      </div>
                    </div>           
                   
                    <div class="form-group row mt-2">
                      <label for="word" class="col-md-3 col-form-label text-md-right">Article</label>
                      <div class="col-md-9">
                        <textarea class="content form-control <?php if ($errors->has('word')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('word'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" rows="9" name="word" required>
                          <?php echo e($aword->word ?? old('word')); ?>

                        </textarea> 
                      </div>                                  
                    </div>                  
                    <div class="compose-btn">
                      <button class="btn btn-theme btn-sm" type="submit"><i class="fa fa-check"></i> Save Changes</button>
                       <a href="/admin" class="btn btn-danger btn-sm"><i class="fa fa-home"></i> cancel</a>
                      
                    </div>
                  </form>
         </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/jquery3.1.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.richtext.min.js')); ?>"></script>
<script>
  $('.content').richText({
  // text formatting
  bold: true,
  italic: true,
  underline: true,

  // text alignment
  leftAlign: true,
  centerAlign: true,
  rightAlign: true,

  // lists
  ol: true,
  ul: true,

  // title
  heading: true,

  // fonts
  fonts: true,
  fontList: ["Arial", 
    "Arial Black", 
    "Comic Sans MS", 
    "Courier New", 
    "Geneva", 
    "Georgia", 
    "Helvetica", 
    "Impact", 
    "Lucida Console", 
    "Tahoma", 
    "Times New Roman",
    "Verdana"
    ],
  fontColor: true,
  fontSize: true,

  // uploads
  imageUpload: true,
  fileUpload: true,

  // media
  videoEmbed: true,

  // link
  urls: true,

  // tables
  table: true,

  // code
  removeStyles: true,
  code: true,

  // colors
  colors: [],

  // dropdowns
  fileHTML: '',
  imageHTML: '',

  // translations
  translations: {
    'title': 'Title',
    'white': 'White',
    'black': 'Black',
    'brown': 'Brown',
    'beige': 'Beige',
    'darkBlue': 'Dark Blue',
    'blue': 'Blue',
    'lightBlue': 'Light Blue',
    'darkRed': 'Dark Red',
    'red': 'Red',
    'darkGreen': 'Dark Green',
    'green': 'Green',
    'purple': 'Purple',
    'darkTurquois': 'Dark Turquois',
    'turquois': 'Turquois',
    'darkOrange': 'Dark Orange',
    'orange': 'Orange',
    'yellow': 'Yellow',
    'imageURL': 'Image URL',
    'fileURL': 'File URL',
    'linkText': 'Link text',
    'url': 'URL',
    'size': 'Size',
    'responsive': 'Responsive',
    'text': 'Text',
    'openIn': 'Open in',
    'sameTab': 'Same tab',
    'newTab': 'New tab',
    'align': 'Align',
    'left': 'Left',
    'center': 'Center',
    'right': 'Right',
    'rows': 'Rows',
    'columns': 'Columns',
    'add': 'Add',
    'pleaseEnterURL': 'Please enter an URL',
    'videoURLnotSupported': 'Video URL not supported',
    'pleaseSelectImage': 'Please select an image',
    'pleaseSelectFile': 'Please select a file',
    'bold': 'Bold',
    'italic': 'Italic',
    'underline': 'Underline',
    'alignLeft': 'Align left',
    'alignCenter': 'Align centered',
    'alignRight': 'Align right',
    'addOrderedList': 'Add ordered list',
    'addUnorderedList': 'Add unordered list',
    'addHeading': 'Add Heading/title',
    'addFont': 'Add font',
    'addFontColor': 'Add font color',
    'addFontSize' : 'Add font size',
    'addImage': 'Add image',
    'addVideo': 'Add video',
    'addFile': 'Add file',
    'addURL': 'Add URL',
    'addTable': 'Add table',
    'removeStyles': 'Remove styles',
    'code': 'Show HTML code',
    'undo': 'Undo',
    'redo': 'Redo',
    'close': 'Close'
  },

  // dev settings
  useSingleQuotes: false,
  height: 0,
  heightPercentage: 0,
  id: "",
  class: "",
  useParagraph: false
  
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\html\pefa_njiru\resources\views/article/edit.blade.php ENDPATH**/ ?>