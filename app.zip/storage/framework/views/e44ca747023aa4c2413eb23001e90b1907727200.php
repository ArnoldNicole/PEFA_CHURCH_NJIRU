<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	 <div id="demo" class="carousel slide" data-ride="carousel">

	   <!-- Indicators -->
	   <ul class="carousel-indicators">
	     <li data-target="#demo" data-slide-to="0" class="active"></li>
	     <li data-target="#demo" data-slide-to="1"></li>
	     <li data-target="#demo" data-slide-to="2"></li>
	     <li data-target="#demo" data-slide-to="3"></li>
	     <li data-target="#demo" data-slide-to="4"></li>
	     <li data-target="#demo" data-slide-to="5"></li>
	   </ul>
	   
	   <!-- The slideshow -->
	   <div class="carousel-inner">
	     <div class="carousel-item active">
	       <img src="/storage/bible.jpeg" alt="Bible" width="1100" height="500">
	       <div class="carousel-caption d-none d-md-block">
	           <h5>The Bible</h5>
	           <p class="text-primary">The Bible is the living word of the Most High</p>
	         </div>
	     </div>
	     <div class="carousel-item">
	       <img src="/storage/flowers.jpeg" alt="flowers" width="1100" height="500">
	       <div class="carousel-caption d-none d-md-block">
	           <h5>Joy</h5>
	           <p class="text-primary">And there was love</p>
	         </div>
	     </div>
	     <div class="carousel-item">
	       <img src="/storage/gates.jpeg" alt=gates width="1100" height="500">
	       <div class="carousel-caption d-none d-md-block">
	           <h5>Open Heavens</h5>
	           <p class="text-primary">Trough prayers, make your wants known</p>
	         </div>
	     </div>

	     <div class="carousel-item">
	       <img src="/storage/gates_chained.jpeg" alt=gates width="1100" height="500">
	       <div class="carousel-caption d-none d-md-block">
	           <h5>Broken Chains</h5>
	           <p class="text-primary">In the name of the Lord there is power to break every chain</p>
	         </div>
	     </div>

	     <div class="carousel-item">
	       <img src="/storage/wind_spirit.jpeg" alt=gates width="1100" height="500">
	       <div class="carousel-caption d-none d-md-block">
	           <h5>Spirit, Roaming</h5>
	           <p  class="text-primary">The Spirit is un seerbale. We see its actions</p>
	         </div>
	     </div>

	     <div class="carousel-item">
	       <img src="/storage/bible_humble.jpeg" alt=gates width="1100" height="500">
	       <div class="carousel-caption d-none d-md-block">
	           <h5>Open Heavens</h5>
	           <p class="text-primary">Trough prayers, make your wants known</p>
	         </div>
	     </div>
	   </div>
	   
	   <!-- Left and right controls -->
	   <a class="carousel-control-prev" href="#demo" data-slide="prev">
	     <span class="carousel-control-prev-icon"></span>
	   </a>
	   <a class="carousel-control-next" href="#demo" data-slide="next">
	     <span class="carousel-control-next-icon"></span>
	   </a>
	 </div>
	 <div class="row pt-5 ">
	 	<div class="col">
	 		<div class="mx-auto mb-5 mb-lg-0 mb-lg-3">
	 		           <div class="features-icons-icon d-flex">
	 		             <i class="icon-screen-desktop m-auto text-primary"></i>
	 		           </div>
	 		           <h3 class="text-center  " style="color: #0115FC">Mission</h3>
	 		           <p class="lead mb-0">Our Mission is to build and expand the Kingdom of God, by preaching and teaching the holistic Gospel of Jesus Christ for the transformation and fulfillment of lives
	 		           </p>
	 		         </div>
	 		</div>
	 	<div class="col">
	 		<div class="mx-auto mb-5 mb-lg-0 mb-lg-3">
	 		           <div class="features-icons-icon d-flex">
	 		             <i class="icon-screen-desktop m-auto text-primary"></i>
	 		           </div>
	 		           <h3 class="text-center " style="color: #0115FC">Mission</h3>
	 		           <p class="lead mb-0">Our vision is to be A Church That Knows Christ and Makes Him Known To The World</p>
	 		         </div>

	 	</div>
	 	<div class="col">
	 		
	 		<div class="mx-auto mb-5 mb-lg-0 mb-lg-3">
	 		           <div class="features-icons-icon d-flex">
	 		             <i class="icon-screen-desktop m-auto text-primary"></i>
	 		           </div>
	 		           <h3 class="text-center " style="color: #0115FC">Commitment</h3>
	 		           <p class="lead mb-0">Commitment, Compassion, Competence, Innovation, Team Work, Transparency, Faith, Stewardship, Hope,Integrity, Service, Peace, Humanity & Accountability</p>
	 		         </div>
	 	</div>
	 </div><?php
	 /*
	 <section id="team">
	       <div class="container wow fadeInUp">
	         <div class="section-header">
	           <h3 class="section-title">United for a bigger purpose</h3>
	           <p class="section-description">At the wheel of PEFA Njiru</p>
	         </div>
	         <div class="row">
	           <div class="col-lg-3 col-md-6">
	             <div class="member">
	               <div class="pic"><img src="/storage/default.jpeg" alt=""></div>
	               <h4>Pastor</h4>
	               <span>Team Leader</span>
	               <div class="social">
	                 <a href=""><i class="fa fa-twitter"></i></a>
	                 <a href=""><i class="fa fa-facebook"></i></a>
	                 <a href=""><i class="fa fa-google-plus"></i></a>
	                 <a href=""><i class="fa fa-linkedin"></i></a>
	               </div>
	             </div>
	           </div>

	           <div class="col-lg-3 col-md-6">
	             <div class="member">
	               <div class="pic"><img src="/storage/default.jpeg" alt=""></div>
	               <h4>Mr .....</h4>
	               <span>Chairman </span>
	               <div class="social">
	                 <a href=""><i class="fa fa-twitter"></i></a>
	                 <a href=""><i class="fa fa-facebook"></i></a>
	                 <a href=""><i class="fa fa-google-plus"></i></a>
	                 <a href=""><i class="fa fa-linkedin"></i></a>
	               </div>
	             </div>
	           </div>

	           <div class="col-lg-3 col-md-6">
	             <div class="member">
	               <div class="pic"><img src="/storage/default.jpeg" alt=""></div>
	               <h4>Ms......</h4>
	               <span>Secretary </span>
	               <div class="social">
	                 <a href=""><i class="fa fa-twitter"></i></a>
	                 <a href=""><i class="fa fa-facebook"></i></a>
	                 <a href=""><i class="fa fa-google-plus"></i></a>
	                 <a href=""><i class="fa fa-linkedin"></i></a>
	               </div>
	             </div>
	           </div>

	           <div class="col-lg-3 col-md-6">
	             <div class="member">
	               <div class="pic img-fluid"><img src="/storage/default.jpeg" alt="" style="border-radius: 80px"></div>
	               <h4>Arnold Wamae</h4>
	               <span>Our web systems developer</span>
	               <div class="social">
	                 <a href="https://twitter.com/wamae_arnold"><i class="fa fa-twitter"></i></a>
	                 <a href="https://facebook.com/samearnoldnyaga"><i class="fa fa-facebook"></i></a>
	                 
	               </div>
	             </div>
	           </div>
	         </div>

	       </div>
	     </section><!-- #team -->
	     */
	     ?>

	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\html\pefa_njiru\resources\views/home.blade.php ENDPATH**/ ?>