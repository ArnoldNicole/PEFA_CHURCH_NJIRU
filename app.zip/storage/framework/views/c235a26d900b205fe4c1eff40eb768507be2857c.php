<?php $__env->startSection('content'); ?>
<div class="container mt-5"> 
  <?php if($featuredArticles!=null): ?>
 <div class="row justify-content-center mt-5">
   <div class="col-md-8">     
       <div class="row justify-content-center" class="d-flex pt-5">
       
       <div class="col-10">
         <span class="lead mb-0">
           <h2 class ="text-success"><?php echo e($featuredArticles->title); ?></h2> by <strong><em><?php echo e($featuredArticles->author); ?></em></strong>     
          
          </span> 
          <article>
            <?php echo html_entity_decode($featuredArticles->word); ?>

          </article>    
          <span class="font-weight-bold text-info float-right">Created : <?php echo e($featuredArticles->created_at->diffForHumans()); ?></span>
          <br>
       </div>
      
       </div>
        
   </div>
  
    <div class="col-md-4">
      <a href="#Comment" class="btn btn-block btn-outline-info">Add Comment</a>
      <h5 class="text-center">You may also like</h5>
      <ul class="list-group">
        <?php $__currentLoopData = $Articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($featuredArticles->id!=$Article->id): ?>
            <li class="list-group-item">
              <a href="/a_word/<?php echo e($Article->id); ?>"><h6><?php echo e($Article->title); ?></h6></a>
              <?php echo html_entity_decode(substr($Article->body, 0, 200)); ?>

            </li>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>

 </div>
 <div class="row justify-content-center">
   <div class="col-md-12">
     <div class="card">
       <div class="card-header text-info font-weight-bold bg-light">Comments</div>
       <div class="card-body border border-top-0 border-info">
          <?php if($featuredArticles->comments->count()==0): ?>
         <span class="alert alert-info font-weight-bold">Add First Comment Below</span>
         <?php else: ?>
           <div class="row justify-content-center border border-primary">
             <div class="col-md-10">
               <?php $__currentLoopData = $featuredArticles->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php if($comment->fine=="yes"): ?>
                 <div class="row justify-content-center border border-top-0 border-success border-left-0 border-right-0">
                   <div class="col-md-3">
                     
                     <div class="d-flex align-items-center">
                       
                         <i class="fa fa-user rounded-circle  text-gray-dark mt-2" style="font-size: xx-large;"></i>
                       
                           <div>
                             <div class="font-weight-bold">
                               <a href="#">
                                 <span class="text-dark font-weight-bold"><?php echo e($comment->name); ?></span>
                               </a>                            
                             </div>
                           </div>

                     </div>                             
                         
                   </div>
                   <div class="col-md-9">
                     <div class="mt-1">
                             <div class="font-weight-normal">                           
                                 <div><span class="text-dark"><?php echo e($comment->comment); ?></span></div>
                                 <div class="font-weight-bold text-info"><?php echo e($comment->created_at->diffForHumans()); ?></div>
                                                        
                            </div>
                            <?php if(Auth::check()==true): ?>
                             <a href="/admin/take_comment_down/<?php echo e($comment->id); ?>" class="text-info">Take this comment Down</a>
                           <?php endif; ?> 
                     </div>
                     
                   </div>
                 </div>
                 <?php endif; ?>
                 
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </div>
           </div>
         <?php endif; ?>
       
       <div class="row justify-content-center mb-lg-5">
         <div class="col-md-12">
           <p class="text-left text-success font-weight-bold ml-3">Add your Comment Here</p>
           <div class="row justify-content-center">
             <div class="col-md-12">
               <form action="/pefa_comments_section/New/<?php echo e($featuredArticles->id); ?>" class="form" method="POST" id="Comment">
                 <?php echo csrf_field(); ?>
                 <div class="form-group-row">
                   <label for="name" class="col-md-4">Name</label>
                   <div class="input-group col-md-8">
                     <input type="text" name="name" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"  value="<?php echo e(@old('name')); ?>" required>
                     <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                      <span class="invalid-feedback"><?php echo e($message); ?></span>
                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                   </div>
                 </div>

                 <div class="form-group-row">
                   <label for="email" class="col-md-4">Email</label>
                   <div class="input-group col-md-8">
                     <input type="email" name="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(@old('email')); ?>" required>
                     <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                      <span class="invalid-feedback"><?php echo e($message); ?></span>
                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                   </div>
                 </div>

                 <div class="form-group-row">
                   <label for="comment" class="col-md-4">Comment</label>
                   <div class="input-group col-md-8">
                     <textarea name="comment" class="form-control <?php if ($errors->has('comment')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('comment'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" required> <?php echo e(@old('comment')); ?></textarea>
                     <?php if ($errors->has('comment')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('comment'); ?>
                      <span class="invalid-feedback"><?php echo e($message); ?></span>
                      <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                   </div>
                 </div>

                 <div class="form-group-row mt-2">
                   
                   <div class="input-group col-md-8 mb-4">
                     <button type="submit" class="btn btn-block btn-outline-primary">Comment</button>
                   </div>
                 </div>
               </form>
             </div>
           </div>
         </div>
       </div>
       </div>
     </div>
   </div>
 </div>
   
<?php endif; ?>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\html\pefa_njiru\resources\views/messages.blade.php ENDPATH**/ ?>