<?php $__env->startSection('content'); ?>
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800"><?php echo e(auth()->user()->name); ?> </h1>
          </div>
          <form action="/admin/profile/saveImage" method="post" accept-charset="utf-8" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <div class="form-panel">

              <div class="form-group">
                <label>Choose your profile Image</label>
                input
                <input type="file" name="image" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" required>
                <?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?>
                <div class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </div>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </div>
              <div class="text-center">
                <button class="btn btn-primary" type="submit">Save Image</button>

              </div>
           
            </div>
          </form>


          <!-- Content Row -->

        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\html\pefa_njiru\resources\views/admin/imageForm.blade.php ENDPATH**/ ?>