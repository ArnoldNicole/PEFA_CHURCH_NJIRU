<?php $__env->startSection('content'); ?>
        <div class="container-fluid">
              <?php if(\Session::has('success')): ?>
              <div class="alert alert-danger my-alert" >
                  <hr>    
                  <ul>
                      <li><?php echo \Session::get('success'); ?></li>
                  </ul>
              </div>
          <?php endif; ?>
          <script>
              document.querySelector('.my-alert').style.display = 'block';
          setTimeout(function() {
            document.querySelector('.my-alert').style.display = 'none';
          }, 4000);
              </script>

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800"><?php echo e(auth()->user()->name); ?> create a new site Article </h1>
          </div>
          <form role="form-horizontal"  action="/admin/article/save" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                          <label class="col-form-label text-md-right">Title</label>
                          <div class="input-group">            
                              <input type="text" name="title" 
                              class="form-control <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('title')); ?>" required>
                          
                          <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
                              <span class="invalid-feedback" role="alert">
                                  <strong><?php echo e($message); ?></strong>
                              </span>
                          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>   
                          </div>      
                        </div>            
                       
                        <div class="compose-editor">
                          <textarea class="wysihtml5 form-control <?php if ($errors->has('word')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('word'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" rows="9" name="word" value="<?php echo e(old('body')); ?>" required></textarea><hr>
                                       <?php if ($errors->has('word')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('word'); ?>
                                           <span class="invalid-feedback" role="alert">
                                               <strong><?php echo e($message); ?></strong>
                                           </span>
                                       <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> 
                        </div>
                        <div class="compose-btn">
                          <button class="btn btn-theme btn-sm" type="submit"><i class="fa fa-check"></i> Save</button>
                           <a href="/admin" class="btn btn-danger btn-sm"><i class="fa fa-home"></i> cancel</a>
                          
                        </div>
                      </form>
                    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.note_edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\html\pefa_njiru\resources\views/admin/newArticleForm.blade.php ENDPATH**/ ?>