<?php echo e($slot); ?>

<?php /**PATH F:\html\pefa_njiru\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>