<?php $__env->startComponent('mail::message'); ?>
# Thanks For contacting PEFA CHURCH NJIRU





Thanks,All the best<br>
Arnold Wamae PEFA CHURCH NJIRU ADMIN
<?php echo $__env->renderComponent(); ?>
<?php /**PATH F:\html\pefa_njiru\resources\views/emails/email.blade.php ENDPATH**/ ?>