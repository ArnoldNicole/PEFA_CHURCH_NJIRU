<?php $__env->startSection('content'); ?>
        <div class="container-fluid bg-info">
              <?php if(\Session::has('success')): ?>
              <div class="alert alert-danger my-alert" >
                  <hr>    
                  <ul>
                      <li><?php echo \Session::get('success'); ?></li>
                  </ul>
              </div>
          <?php endif; ?>
          <script>
              document.querySelector('.my-alert').style.display = 'block';
          setTimeout(function() {
            document.querySelector('.my-alert').style.display = 'none';
          }, 4000);
              </script>

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800"><?php echo e(auth()->user()->name); ?> Weekly News Article create Center </h1>
          </div>
          <form role="form-horizontal"  action="/admin/weekly/save" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                          <label class="col-form-label text-md-right">Day</label>
                          <div class="input-group">            
                              <select name="day" class="form-control">
                                <option value="Monday">Monday</option>
                                 <option value="Tuesday">Tuesday</option>
                                  <option value="Wednesday">Wednesday</option>
                                   <option value="Thursday">Thursday</option>
                                    <option value="Friday">Friday</option>
                                     <option value="Saturday">Saturday</option>
                                      <option value="Sunday">Sunday</option>
                               
                              </select>
                          
                          <?php if ($errors->has('day')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('day'); ?>
                              <span class="invalid-feedback" role="alert">
                                  <strong><?php echo e($message); ?></strong>
                              </span>
                          <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>   
                          </div>      
                        </div>            
                       
                        <div class="compose-editor">
                          <textarea class="wysihtml5 form-control <?php if ($errors->has('event')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('event'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" rows="3" name="event" value="<?php echo e(old('event')); ?>" required></textarea><hr>
                                       <?php if ($errors->has('event')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('event'); ?>
                                           <span class="invalid-feedback" role="alert">
                                               <strong><?php echo e($message); ?></strong>
                                           </span>
                                       <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> 
                        </div>
                        <div class="compose-btn">
                          <button class="btn btn-theme btn-sm" type="submit"><i class="fa fa-check"></i> Save</button>
                           <a href="/admin" class="btn btn-danger btn-sm"><i class="fa fa-home"></i> cancel</a>
                          
                        </div>
                      </form>
                    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.note_edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arnoldn/projects/pefa_njiru/resources/views/admin/newWeeklyEvent.blade.php ENDPATH**/ ?>