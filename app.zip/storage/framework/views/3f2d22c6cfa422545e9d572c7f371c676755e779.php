<?php $__env->startSection('content'); ?>
        <div class="container-fluid">
              <?php if(\Session::has('success')): ?>
              <div class="alert alert-danger my-alert" >
                  <hr>    
                  <ul>
                      <li><?php echo \Session::get('success'); ?></li>
                  </ul>
              </div>
          <?php endif; ?>
          <script>
              document.querySelector('.my-alert').style.display = 'block';
          setTimeout(function() {
            document.querySelector('.my-alert').style.display = 'none';
          }, 4000);
              </script>

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800"><?php echo e(auth()->user()->name); ?> </h1>
          </div>
          <form action="/admin/profile/saveProfile" method="post" accept-charset="utf-8" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <div class="form-panel">

              <div class="form-group">
                <label>Bio</label>
                input
                <input type="text" name="bio" class="form-control <?php if ($errors->has('bio')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('bio'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('bio') ?? $profile->bio); ?>" required>
                <?php if ($errors->has('bio')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('bio'); ?>
                <div class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </div>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </div>
              <div class="form-group">
                <label>Description</label>
                input
                <input type="text" name="description" class="form-control <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('description') ?? $profile->description); ?>" required>
                <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
                <div class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </div>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </div>
             
              <div class="text-center">
                <button class="btn btn-primary" type="submit">Save Changes</button>

              </div>
           
            </div>
          </form>


          <!-- Content Row -->

        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\html\pefa_njiru\resources\views/admin/profileChangeForm.blade.php ENDPATH**/ ?>