<?php $__env->startSection('content'); ?>
<div class="container">
  <div>
    <br>
    <br>
    <br>    
  </div>
 
   <?php $__currentLoopData = $featuredArticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row" class="d-flex pt-5">
    <div class="col-4">
      <img src='/storage/default.jpeg' class="img-fluid  img-rounded img-thumbnail" style="border-radius: 100px">
    </div>
    <div class="col-8">
      <span class="lead mb-0">
        <h2 class ="text-success"><?php echo e($message->title); ?></h2> by <strong><em><?php echo e($message->author); ?></em></strong>
        <article>
          <?php echo html_entity_decode($message->word); ?>

        </article>
       
       </span>
       
       <?php echo e($message->created_at); ?>

       <br>
    </div>
    <br>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
<hr>
 


   

	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arnoldn/projects/pefa_njiru/resources/views/messages.blade.php ENDPATH**/ ?>