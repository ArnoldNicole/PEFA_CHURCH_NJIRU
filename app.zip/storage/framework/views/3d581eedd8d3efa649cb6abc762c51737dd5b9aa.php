<?php $__env->startSection('content'); ?>
<div class="container">
<div class="row mt-5"> 

  <div class="col-8 mt-4">
        <img src="/storage/<?php echo e($image->image); ?>" class="w-100 " >
    </div>
    <div class="col-4">

      <div class="d-flex align-items-center">
        <div class="pr-3">
          <img src="" class="rounded-circle w-100" style="max-width: 50px">
        </div>
             <div>
              <div class="font-weight-bold">
                <a href="/profile/<?php echo e($image->user->id); ?>">
                  <span class="text-dark"><?php echo e($image->user->username); ?></span>
                </a>
                <a href="/p/<?php echo e(($image->id - 1)); ?>" class="btn btn-outline-primary rounded-circle <?php if(App\images::find($image->id - 1)==null): ?> disabled " title="No Previous Photo"<?php else: ?> title="Previous Photo" <?php endif; ?>><i class="fa fa-arrow-left font-weight-bold"></i></a>
               <a href="/p/<?php echo e($image->id + 1); ?>" class="btn btn-outline-primary rounded-circle <?php if(App\images::find($image->id + 1)==null): ?> disabled"
                  title="No Next Photo" <?php else: ?> title="Next Photo" <?php endif; ?>><i class="fa fa-arrow-right font-weight-bold"></i></a>
                
              </div>
            </div>

      </div>

      <hr>
        <p class="mt-5">
          <span class="font-weight-bold">
          <a href="#" title="">
            <span class="text-success"><?php echo e($image->caption); ?></span>
          </a>
        </span><br>
          
         <span class="text-info font-weight-bold">posted <?php echo e($image->created_at->diffForHumans()); ?></span>
          </p>            
            
         
    </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\html\pefa_njiru\resources\views/image.blade.php ENDPATH**/ ?>