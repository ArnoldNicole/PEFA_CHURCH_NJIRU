<?php $__env->startSection('content'); ?>
<div class="row justify-content-center mt-3">
	<div class="col-md-12 mt-2">
		<div class="card">
			<div class="card-header">Add a New Admin To Website</div>
			<div class="card-body">
				<form action="/admin/save/newAdmin/" method="POST">
					<?php echo csrf_field(); ?>
					<div class="form-group row">
						<label for="" class="col-md-3">Email Address</label>
						<div class="input-group col-md-9">
							<input type="email" name="admin_code" class="form-control <?php if ($errors->has('admin_code')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('admin_code'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" value="<?php echo e(old('admin_code')); ?> ">
							<?php if ($errors->has('admin_code')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('admin_code'); ?>
								<span class="invalid-feedback alert alert-danger"><?php echo e($message); ?></span>
							<?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
						</div>
					</div>

					<div class="form-group row">
						<div class="col-md-12">
							<button type="submit" class="btn tbtn-block btn-outline-success">Create Admin</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\html\pefa_njiru\resources\views/admin/AddNewAdmin.blade.php ENDPATH**/ ?>