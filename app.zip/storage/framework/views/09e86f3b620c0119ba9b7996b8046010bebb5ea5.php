<?php $__env->startSection('content'); ?>
<div class="container-fluid" style="overflow-y: scroll;">


  <div class="row justify-content-center">
    <div class="col-md-12">
      <?php if(\Session::has('success')): ?>
                  <div class="alert alert-success my-alert" >
                      <hr>    
                      <ul>
                          <li><?php echo \Session::get('success'); ?></li>
                      </ul>
                  </div>
              <?php endif; ?>
              <script>
                  document.querySelector('.my-alert').style.display = 'block';
              setTimeout(function() {
                document.querySelector('.my-alert').style.display = 'none';
              }, 4000);
                  </script>
    </div>
  </div>


<div class="row justify-content-center">
  <div class="col-md-12">   
    <?php if($articles->count()==0): ?>
    <span class="alert alert-danger">No approved article available.</span>
    <?php else: ?>
      <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="row">
        <div class="col-md-12">
            
            

            <div class="row justify-content-center">
              <div class="col-md-12">
                <span>
                  <strong>
                  <a href='/admin/profile/<?php echo e($note->user_id); ?>'>
                    <?php echo e($note->author); ?>

                  </a>
                </strong>
                  </span>
                <i class="fa fa-arrow-right"></i>
                <span class="success"><?php echo e($note->title); ?></span>
              </div>
            </div>

            
            <?php if(Auth::user()==$note->user): ?> 
            <div class="row justify-content-center mb-2">
              <div class="col-md-4">
                
                   <?php if($note->featured=="no"): ?>
                   <a class="btn btn-primary btn-block" href="/article/feature/<?php echo e($note->id); ?>" title="Featuerd articles appear on website.">Make Featured</a>

                   <?php else: ?>
                   <form action="/admin/article/takedown/<?php echo e($note->id); ?>" method="POST">
                     <?php echo csrf_field(); ?>
                     <?php echo method_field('PATCH'); ?>
                     <input type="hidden" name="featured" value="no">
                     <button type="submit" title="Remove from Site" class="btn btn-outline-warning  btn-block"><i class="fa fa-user"></i> Remove</button>
                   </form>
                   <?php endif; ?>
                   

                     
                     
                   
              </div>

              <div class="col-md-4">
                
                <form action="/admin/article/delete/<?php echo e($note->id); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button type="submit" title="Delete Completely" class="btn btn-outline-danger btn-block "><i class="fa fa-trash"></i>Delete</button>
                </form>
                
              </div>

              <div class="col-md-4">
                
              <a href="/admin/article/edit/<?php echo e($note->id); ?>" class="btn btn-outline-primary btn-block"><i class="fa fa-edit"> Edit</i></a>                
              </div>
            </div>

            <?php endif; ?>

            
            <div class="row">
              <div class="col-md-12">
                <div class="row justify-content-center">
                  <div class="col-md-12">
                    <div class="card">
                      <div class="card-body">
                        <?php echo html_entity_decode($note->word); ?>

                        <div class="dropdown-divider"></div>

                        <div class="row">
                          <div class="col-md-12">
                             <h4 class="h4 text-danger text-sm-center">Unsafe Comments for <?php echo e($note->title); ?></h4>
                             <?php $__currentLoopData = $note->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php if($comment->fine!="yes"): ?>
                               <div class="row justify-content-center text-dark border border-info mb-2 ">
                                <div class="col-md-5">
                                   <p class="p3 font-weight-bold"><?php echo e($comment->name); ?></p>
                                   <span>If you think the comment meets the standards, click below to make it visible on website</span>
                                   <a href="/admin/take_comment_up/<?php echo e($comment->id); ?>" class="btn btn-info btn-block mb-2">Comment is Safe</a>
                                </div>
                                 <div class="col-md-7 border border-primary"> 
                                    <p class="p3 text-dark"><?php echo e($comment->comment); ?></p>
                                    <span class="card-link"><a href="mailto:<?php echo e($comment->email); ?>"><?php echo e($comment->email); ?></a></span>
                                </div>
                               </div>        
                              <?php endif; ?>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

        </div>
      </div>                                
    

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    
  </div>
  
</div>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\html\pefa_njiru\resources\views/admin/approvedArticle.blade.php ENDPATH**/ ?>