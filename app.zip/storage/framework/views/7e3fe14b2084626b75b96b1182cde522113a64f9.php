<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	<div>
		<hr>
		<br>
		<marquee>Welcome for the latest news from PEFA</marquee>
	</div>
	       </div>
	       <div class="row">
	       	<div class="col-md-2">
	       		
	       	</div>
	       	<div class="col-md-8 mb-5">
	       		<?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	       		<div class="card">
	       			<div class="card-header"><?php echo e($new->title); ?></div>
	       			<div class="card-body"><?php echo e($new->body); ?></div>
	       		</div>
	       		<hr>
	       		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	       	</div>
	       		<div class="col-md-2">
	       		
	       	</div>
	       </div>     


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arnoldn/projects/pefa_njiru/resources/views/news.blade.php ENDPATH**/ ?>