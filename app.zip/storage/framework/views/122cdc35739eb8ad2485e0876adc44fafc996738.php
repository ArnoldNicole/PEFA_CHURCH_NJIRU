<?php $__env->startSection('content'); ?>
     <div class="wow fadeIn">
       <div class="row">
        <h1>Our Weekly Events </h1>
       <hr>
       </div>
       <div class="row">
        <div class="col-md-2">
        </div>
        <?php $__currentLoopData = $weekly; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $week): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="card mt-4">
          <div class="card-header">
            <?php echo e($week->day); ?>

          </div>
          <div class="card-body">
            <?php echo e($week->event); ?>

          </div>           
         </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
         <div class="col-md-2">
        </div>        
       </div>

     </div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.animated', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/arnoldn/projects/pefa_njiru/resources/views/weekly.blade.php ENDPATH**/ ?>