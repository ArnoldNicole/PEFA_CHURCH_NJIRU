<?php $__env->startSection('content'); ?>
        <div class="container-fluid">

          <!-- Page Heading -->
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800"><?php echo e(auth()->user()->name); ?> </h1>
          </div>
          <form action="/admin/createImage/save" method="post" accept-charset="utf-8" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-panel">
              <div class="form-group">
                <label>Caption</label>
                <input type="text" name='caption' class="form-control">
                <?php if ($errors->has('caption')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('caption'); ?>
                <div class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </div>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </div>

              <div class="form-group">
                <label>Select Image</label>
                input
                <input type="file" name="image" class="form-control <?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" required>
                <?php if ($errors->has('image')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('image'); ?>
                <div class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </div>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
              </div>
              <div class="text-center">
                <button class="btn btn-primary" type="submit">Save Image</button>

              </div>
           
            </div>
          </form>


          <!-- Content Row -->

        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\html\pefa_njiru\resources\views/admin/createImageForm.blade.php ENDPATH**/ ?>