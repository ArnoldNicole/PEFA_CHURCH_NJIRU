<?php $__env->startSection('links'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/dataTables.bootstrap4.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/responsive.bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
 
        <div class="col-md-12">
        	<h4 class="text-info h4">Events</h4>
        	<!-- page start-->
        	<div class="content-panel">
        	  <div class="adv-table">
        	    <table cellpadding="0" cellspacing="0" border="0" class="display table table-bordered dt-responsive" id="example">
        	      <thead>
        	        <tr>
        	          <th>Day</th>
        	          <th>Event</th>
        	          <th></th
        	        </tr>
        	        <!--fullname admno upino classadmittedto gender status -->
        	      </thead>
        	      <tbody>
        	        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        	        <tr class="gradeX">
        	          <td><?php echo e($event->day); ?></td>
        	          <td class="border border-info"><?php echo $event->event; ?></td>
        	          <td> <?php if($event->user==auth()->user()): ?> <a href="/admin/weekly_event/<?php echo e($event->id); ?>" class="btn btn-block btn-success">Edit</a>
                        <a href="/admin/weekly_event/delete/<?php echo e($event->id); ?>" class="btn btn-block btn-danger">Delete</a> <?php endif; ?> </td>
        	        </tr> 
        	        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        	                       
        	      </tbody>
        	    </table>
        	  </div>
        	</div>
        </div> 
        
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/jquery3.1.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery.dataTables.min.js')); ?>"></script>
 <script src="<?php echo e(asset('js/dataTables.bootstrap4.min.js')); ?>"></script>
 <script src="<?php echo e(asset('js/dataTables.responsive.min.js')); ?>"></script>
 <script src="<?php echo e(asset('js/responsive.bootstrap4.min.js')); ?>"></script>
 <script>
 
  $('#example').DataTable();
 
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\html\pefa_njiru\resources\views/admin/ViewWeeklyEvent.blade.php ENDPATH**/ ?>