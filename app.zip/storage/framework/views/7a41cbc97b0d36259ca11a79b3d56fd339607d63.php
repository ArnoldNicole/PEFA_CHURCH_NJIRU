<?php $__env->startSection('content'); ?>
<div class="container-fluid">
<div class="row">
  <div class="col-md-1">
  </div>
  <div class="col-md-10">
    <div class="row justify-content-center">
      <div class="col-md-8">
        <h5 class="text-info font-weight-bold h5 text-center mb-2">This page shows all articles recently created and are yet to be approved.</h5>
        <?php if(\Session::has('success')): ?>
                <div class="alert alert-success my-alert mb-3" >
                    <hr>    
                    <ul>
                        <li><?php echo \Session::get('success'); ?></li>
                    </ul>
                </div>
            <?php endif; ?>
            <script>
                document.querySelector('.my-alert').style.display = 'block';
            setTimeout(function() {
              document.querySelector('.my-alert').style.display = 'none';
            }, 4000);
                </script>
      </div>
    </div>
   
   <div class="row justify-content-center mt-4">
     <div class="col-md-12 mt-2">
       <?php if($articles->count()==0): ?>
         <span class="alert alert-danger mt-2">Nothing to show here
           <a href="/admin/createArticle">Create Article Here</a></span>
       <?php else: ?>
         <span>All articles made by users and are not approved.</span>
             <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <div class="card-body well ">
               <div class="d-flex justify-content-center">
               <span><strong><a href='/admin/profile/<?php echo e($note->user_id); ?>'><?php echo e($note->author); ?></a></strong><i class="fa fa-arrow-right"></i></span>
               
               <span class="success"><?php echo e($note->title); ?></span>
               <hr>
             <a class="btn btn-primary btn-sm" href="/article/review/<?php echo e($note->id); ?>" title="Approve">Approve</a>
             <a href="/admin/article/edit/<?php echo e($note->id); ?>" class="btn btn-primary rounded-circle ml-1 mr-1"><i class="fa fa-edit"></i></a>
          
           <br>
               <hr>
             </div>
             <div class="form-panel"> <?php echo html_entity_decode($note->word); ?>

         <hr>
             </div>
             </div>

             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       <?php endif; ?>
       
     </div>
   </div> 
   
  </div>
  <div class="col-md-1">
  </div>
</div>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\html\pefa_njiru\resources\views/admin/approveArticle.blade.php ENDPATH**/ ?>