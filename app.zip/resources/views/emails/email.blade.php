@component('mail::message')
# Thanks For contacting PEFA CHURCH NJIRU





Thanks,All the best<br>
Arnold Wamae PEFA CHURCH NJIRU ADMIN
@endcomponent
