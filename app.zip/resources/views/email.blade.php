<div>
	Hello . We got your message. 
	<br>
	{{$name}}	
</div>