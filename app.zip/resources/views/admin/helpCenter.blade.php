@extends('layouts.admin')

@section('content')
<div class="row justify-content-center" >
	<div class="col-md-12">
		<h4 class="h4 text-info text-capitalize  text-center">Hello {{$user->name}}. Read throught the manual for Help</h4>
		<div class="card">
			<div class="card-body">
				
				<h5 class="text-dark text-info font-weight-bold">Table of Contents</h5>

				<ul id="TableOfContents">
					<li><a href="#Articles">Articles</a></li>
					<li><a href="#WebsiteGallery">Website Gallery</a></li>
					<li><a href="#NewsDesk">News Desk</a></li>					
					<li><a href="#Schedules">Schedules</a></li>
					<li><a href="#Messages">Messages</a></li>
					<li><a href="#Admins">Admins</a></li>
				</ul>




			</div>
		</div>
	</div>
</div>

<div class="row justify-content-center mt-5" id="Articles">
					<div class="col-md-3">
						<img src="{{asset('/img/articlesmenu.png')}}" alt="Articles Menu" class="img-fluid mt-2 ">
					</div>
					<div class="col-md-9">
						<h3 class="h3 font-weight-bold text-info">Articles</h3>
						<div>The Article is a menu item on the admin dashboard.
						It`s submenus include
						<ol>
							<li><a href="/admin/createArticle" title="New Article link" class="card-link text-info">New:</a>
								<p>Use the <kbd>New</kbd> link to create new articles. The articlcan be accessed by the public from the <a href="/aword" target="_blank">A Word</a> setion of our website. Write creative and catchy articles that are christian based to  keep a live audience of our website</p>
								<p>When you click the link a blank work area where you need to create your article. The work area looks as below. </p>
								<img src="{{asset('/img/newarticle.png')}}" alt="" class="img-fluid w-75 mb-1 mt-1">
								<p>The <strong>Title</strong> should be a catcchy line less than twent words that shows highlights the article you create</p>
								<p>The <strong>Blank work area </strong> is the working space where you create the actual image. You are freee to be as creative as possible. When working with images or audio, we advise you to use images on other servers and just use the links. You can use youtubr links for videos and google photos links for photos. This approach helps reduce the load on our application</p>
								<p>After you are contented that your article looks good, click the save button below the work area</p>
								<p>By default articles are <strong>Not aprroved</strong> when saved. and therby not visible by the public</p></li>
							<li><a href="">view all Approved</a>
								<p>This is the second button on the Articles section</p>
								<p>This is used after you have created your articles. By default you cannot approve your own article. When another admin as read your article he/she can the approve it and allow you to show ot on the website. Visit the link to see all articles on the system that have been approved.</p>
								<p>Approved articles visible on the website also attract public comments. The link will also allow you see the comments. and incase a comment seems offending you can take them down. Use the guide <a href="#TakeCommentsDown">here</a></p>
								<p>Also, visit the link to see what other admins have written and approve their content.</p>
							</li>
							<li><a href="">View un Approved Articles</a>
								<p>Immediately articles are created, as mentioned earlier, their state is <strong>UnApprovced</strong>. You can click the link above to view all the articles that are seeing approval from you.
									On the page you get after clicking the link, click on the <kbd>Approve</kbd> button to approve it. We are currently working on rewarding admins with most approvals with tickets and pefa badges used to get exclusive rights on content you create and the audience grown.</p>
							</li>
						</ol>
					</div>
					</div>
</div>

<div class="row justify-content-center mt-5" id="WebsiteGallery">
	<div class="col-md-3">
		<img src="{{asset('img/gallerymenu.png')}}" alt="" class="img-fluid mt-2">
	</div>
	<div class="col-md-9">
		<h4 class="h3 font-weight-bold text-info">The Website Gallery</h4>
		<p>We are having a nice gallery available <a href="/gallery">Here</a>. It is controlled by a powerful backend that saves all image links on our database and stores nicely cropped images on the server. We crop and rename the images to prevent malicious images reaching our application.</p>
		<p>The gallery is controlled by only one button. We are currently only supporting uploads. We are working on the <kbd>Edit Image</kbd> and will be ready soon.</p>
		<p>Use the <kbd>New</kbd> to add new images to the gallery. Also give the images nice captions to provide relevance.</p>
		<p>An illustration of our upload form is as below
			<img src="{{asset('img/galleryupload.png')}}" alt="" class="img-fluid mt-2 w-75">
			The other button labelled <kbd>Gallery</kbd> redirects you to the actual gallery on a new browser window</p>
			<p>The gallery upload page requiresa caption which is used as the titile to the iage and also displayed on the page where our visitors get to see our photos</p>
	</div>
</div>

<div class="row justify-content-center mt-2 border border-bottom-0 border-left-0 border-right-0 border-info" id="NewsDesk">
	<div class="col-md-8">
		<h4 class="h3 font-weight-bold text-info">NewsDesk</h4>
		<p>The news desk is a section where our admins should use to write all the new happenings of the church and any chnages on the website. The news will appera on the website immediately and do not need approvals. The news also are supported for editing. The create and edit workspaces for te articles look the same. Image is as below.</p>
		<p><strong>The news pass some verification</strong> by the website and all writers should  be keen with the articles. </p>
		<p><strong>Fake News</strong> We strongly capmapign against sharing of fake news. Any news written on our website can be taken down any time we suspect it to be fake news. Also remember to cite sources from which you get your news.</p>
		<p>All the best.</p>
		<h5 class="text-info">All</h5>
		<p>The <kbd>All</kbd> link on the submenu under news is used when the admins wish to view all the news written by other users.</p>


	</div>
	<div class="col-md-4">
		<img src="{{asset('img/newsdesk.png')}}" alt="" class="img-fluid mt-2 ">
	</div>
</div>


<div class="row justify-content-center mt-2 border border-info border-left-0 border-right-0" id="Schedules">
<div class="col-md-4">
	<img src="{{asset('img/.png')}}" alt="" class="img-fluid mt-3">
</div>
<div class="col-md-8">
	<h4 class="h4 text-info font-weight-bold text-center">Schedules</h4>
</div>	
</div>
<div class="row justify-content-center mt-2 border border-info border-left-0 border-right-0" id="Messages">
<div class="col-md-4">
	<img src="{{asset('img/.png')}}" alt="" class="img-fluid mt-3">
</div>
<div class="col-md-8">
	<h4 class="h4 text-info font-weight-bold text-center">Messages</h4>
</div>	
</div>
<div class="row justify-content-center mt-2 border border-info border-left-0 border-right-0" id="Admins">
<div class="col-md-4">
	<img src="{{asset('img/.png')}}" alt="" class="img-fluid mt-3">
</div>
<div class="col-md-8">
	<h4 class="h4 text-info font-weight-bold text-center">Admins</h4>
</div>	
</div>
<div class="row justify-content-center mt-2 border border-info border-left-0 border-right-0" id="">
<div class="col-md-4">
	<img src="{{asset('img/.png')}}" alt="" class="img-fluid mt-3">
</div>
<div class="col-md-8">
	<h4 class="h4 text-info font-weight-bold text-center">Others</h4>
</div>	
</div>
@endsection